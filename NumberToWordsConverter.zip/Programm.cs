﻿var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseNumberValidation();

app.UseNumberConversion();

app.Run(async context =>
{
    if (context.Items.ContainsKey("NumberInWords"))
    {
        string words = (string)context.Items["NumberInWords"];

        context.Response.ContentType = "text/html; charset=utf-8";
        string htmlResponse = $"<html><body><div style='font-size: 50px;'>Your number is<br>{words}</div></body></html>";

        await context.Response.WriteAsync(htmlResponse);
    }
    else
    {
        await context.Response.WriteAsync("Welcome to the Number Interpreter. Please use the '?Number=X' query parameter.");
    }
});

app.Run();